package com.vizor.optiforge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_310;
import java.util.HashSet;
import java.util.Set;

public class EntityOptimizer {

    private final Set<Integer> culledEntities = new HashSet<>();
    private int tickCounter = 0;
    private int livingCount = 0;
    private int lastLivingCount = 0;
    private boolean scanned = false;

    public void register() {
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            tickCounter++;
            // Реже сканируем (было каждый 4 тик) — на слабом CPU частая итерация по всем
            // сущностям мира вызывала фризы на серверах. Теперь 24 тика (~1.2 сек при 20 TPS).
            if (tickCounter % 24 != 0) return;
            if (!ModConfig.entityCulling) return;

            class_310 mc = class_310.method_1551();
            if (mc.field_1687 == null || mc.field_1724 == null) {
                culledEntities.clear();
                return;
            }

            culledEntities.clear();
            livingCount = 0;
            scanned = true;

            double maxDist = ModConfig.entityRenderDistance * 16.0;
            double maxDistSq = maxDist * maxDist;

            class_243 camPos = mc.field_1724.method_19538();
            float yaw = mc.field_1724.field_6031;
            float fov = 70f;
            double yawRad = Math.toRadians(-yaw);
            double forwardX = -Math.sin(yawRad);
            double forwardZ = Math.cos(yawRad);
            double fovHalfRad = Math.toRadians(fov / 2.0 + 5);
            double cosThreshold = Math.cos(fovHalfRad);

            for (class_1297 entity : mc.field_1687.method_18112()) {
                if (entity == mc.field_1724) continue;
                // Считаем всех живых сущностей (не только предметы) для статистики
                if (entity instanceof class_1309) livingCount++;

                double dx = entity.method_23317() - camPos.field_1352;
                double dy = entity.method_23318() - camPos.field_1351;
                double dz = entity.method_23321() - camPos.field_1350;

                double distSq = dx * dx + dy * dy + dz * dz;
                if (distSq > maxDistSq) {
                    culledEntities.add(entity.method_5628());
                    continue;
                }

                double lenXZ = Math.sqrt(dx * dx + dz * dz);
                if (lenXZ < 0.001) continue;

                double dot = dx * forwardX + dz * forwardZ;
                if (dot / lenXZ < cosThreshold) {
                    culledEntities.add(entity.method_5628());
                }
            }
            lastLivingCount = livingCount;
        });
    }

    // Проверка на переполнение живыми сущностями (по настройке maxLivingEntities)
    public boolean hasLivingOverflow(int entityId) {
        return false;
    }

    public void setLivingCount(int count) {
        this.livingCount = count;
    }

    public boolean isEntityCulled(class_1297 entity) {
        if (!ModConfig.entityCulling) return false;
        return culledEntities.contains(entity.method_5628());
    }

    public int getCulledCount() {
        return culledEntities.size();
    }

    public boolean isScanned() {
        return scanned;
    }

    public int getLastLivingCount() {
        return lastLivingCount;
    }
}
