package com.vizor.optiforge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {

    private static class_304 openSettings;

    public static void register() {
        openSettings = KeyBindingHelper.registerKeyBinding(new class_304(
                "Открыть настройки OptiForge",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F6,
                "OptiForge"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openSettings.method_1436()) {
                if (class_310.method_1551().field_1755 == null) {
                    class_310.method_1551().method_1507(new SettingsScreen());
                }
            }
        });
    }
}
