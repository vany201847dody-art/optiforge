package com.vizor.optiforge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_310;
import java.util.HashSet;
import java.util.Set;

public class ItemOptimizer {

    private final Set<Integer> culledItems = new HashSet<>();
    private int tickCounter = 0;

    public void register() {
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            tickCounter++;
            // Реже сканируем дроп — раньше каждый 8 тик итерация по всем сущностям
            // грузила слабый CPU на серверах. Теперь 20 тиков (~1 сек).
            if (tickCounter % 20 != 0) return;

            class_310 mc = class_310.method_1551();
            if (mc.field_1687 == null || mc.field_1724 == null) {
                culledItems.clear();
                return;
            }

            culledItems.clear();

            int limit = ModConfig.itemLimit;
            if (limit <= 0) limit = 300;

            int count = 0;
            double camX = mc.field_1724.method_23317();
            double camY = mc.field_1724.method_23318();
            double camZ = mc.field_1724.method_23321();

            for (class_1297 entity : mc.field_1687.method_18112()) {
                if (!(entity instanceof class_1542)) continue;

                count++;
                if (count > limit) {
                    culledItems.add(entity.method_5628());
                    continue;
                }

                double dx = entity.method_23317() - camX;
                double dy = entity.method_23318() - camY;
                double dz = entity.method_23321() - camZ;
                int despawn = ModConfig.itemDespawnDistance;
                if (dx * dx + dy * dy + dz * dz > despawn * despawn) {
                    culledItems.add(entity.method_5628());
                }
            }
        });
    }

    public boolean isItemCulled(class_1542 item) {
        if (!ModConfig.optimizeItems) return false;
        return culledItems.contains(item.method_5628());
    }

    public int getCulledCount() {
        return culledItems.size();
    }
}
