package com.vizor.optiforge.mixin;

import com.vizor.optiforge.ModConfig;
import com.vizor.optiforge.OptiForgeMod;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1542;
import net.minecraft.class_310;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_638.class)
public class EntityTickMixin {

    @Inject(method = "tickEntity", at = @At("HEAD"), cancellable = true)
    private void optiforge_skipFarTicks(class_1297 entity, CallbackInfo ci) {
        if (!ModConfig.skipEntityTicks) return;

        class_310 mc = class_310.method_1551();
        if (mc.field_1724 == null || entity == null || entity == mc.field_1724) return;

        // Не трогаем предметы и игроков других — их тики дешёвые/важные
        if (entity instanceof class_1542) {
            // дешёвые, но если их очень много - тоже ограничим через itemOptimizer
            return;
        }

        if (entity instanceof class_1309 && ModConfig.optimizeMobs) {
            double distSq = entity.method_5649(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
            double maxDist = ModConfig.entityTickDistance;
            if (distSq > maxDist * maxDist) {
                ci.cancel();
            }
        }
    }
}
