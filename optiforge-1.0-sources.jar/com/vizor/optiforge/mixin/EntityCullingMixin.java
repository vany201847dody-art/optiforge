package com.vizor.optiforge.mixin;

import com.vizor.optiforge.OptiForgeMod;
import net.minecraft.class_1297;
import net.minecraft.class_4604;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_898.class)
public class EntityCullingMixin {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private <E extends class_1297> void optiforge_cullEntity(E entity, class_4604 frustum, double x, double y, double z,
                                                         CallbackInfoReturnable<Boolean> cir) {
        if (entity == null) return;

        if (OptiForgeMod.entityOptimizer != null && OptiForgeMod.entityOptimizer.isEntityCulled(entity)) {
            cir.setReturnValue(false);
            return;
        }

        if (OptiForgeMod.itemOptimizer != null && entity instanceof net.minecraft.class_1542) {
            if (OptiForgeMod.itemOptimizer.isItemCulled((net.minecraft.class_1542) entity)) {
                cir.setReturnValue(false);
            }
        }
    }
}
