package com.vizor.optiforge;

import net.minecraft.class_310;
import net.minecraft.class_4066;
import net.minecraft.class_5365;

public class GameSettingsApplier {

    public static void apply() {
        class_310 mc = class_310.method_1551();
        if (mc.field_1690 == null) return;

        // Дистанция рендера
        if (ModConfig.renderDistanceOverride > 0) {
            mc.field_1690.field_1870 = ModConfig.renderDistanceOverride;
        }

        // Частицы
        if (ModConfig.optimizedParticles) {
            int limit = ModConfig.particleLimit;
            if (limit <= 20) mc.field_1690.field_1882 = class_4066.field_18199;
            else if (limit <= 60) mc.field_1690.field_1882 = class_4066.field_18198;
            else mc.field_1690.field_1882 = class_4066.field_18197;
        }

        // Графика
        if ("fast".equalsIgnoreCase(ModConfig.graphicsMode)) mc.field_1690.field_25444 = class_5365.field_25427;
        else if ("fancy".equalsIgnoreCase(ModConfig.graphicsMode)) mc.field_1690.field_25444 = class_5365.field_25428;

        // FOV
        if (ModConfig.reduceFov) {
            double fov = mc.field_1690.field_1826;
            if (fov > ModConfig.maxFov) {
                mc.field_1690.field_1826 = ModConfig.maxFov;
            }
        }

        try {
            mc.field_1690.method_1640();
        } catch (Exception ignored) {
        }
    }
}
