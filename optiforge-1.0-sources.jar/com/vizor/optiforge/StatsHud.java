package com.vizor.optiforge;

import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_310;
import net.minecraft.class_4587;

public class StatsHud {

    private final class_310 mc = class_310.method_1551();
    private int fps = 0;
    private int entityCount = 0;
    private int particleCount = 0;
    private int culledEntities = 0;
    private int culledBlockEntities = 0;

    public void register() {
        HudRenderCallback.EVENT.register((matrixStack, tickDelta) -> {
            if (!ModConfig.showFpsHud) return;

            updateStats();

            int x = 5;
            int y = 5;

            net.minecraft.class_332.method_25294(matrixStack, x - 2, y - 2, x + 190, y + 74, 0x80000000);

            draw(matrixStack, "§6OptiForge", x, y, 0xFFFFFF);
            y += 12;

            String fpsColor = fps >= 60 ? "§a" : fps >= 30 ? "§e" : "§c";
            draw(matrixStack, fpsColor + "FPS: " + fps, x, y, 0xFFFFFF);
            y += 12;

            draw(matrixStack, "§bСущности: " + entityCount + " §7(скрыто: " + culledEntities + ")", x, y, 0xFFFFFF);
            y += 12;

            draw(matrixStack, "§dЧастицы: " + particleCount, x, y, 0xFFFFFF);
            y += 12;

            draw(matrixStack, "§eБлок-энтити скрыто: " + culledBlockEntities, x, y, 0xFFFFFF);
            y += 12;
            draw(matrixStack, "§7Профиль: " + HardwareDetector.getTierName() + " §8(" + PerfMode.tierName(HardwareDetector.tier) + ")", x, y, 0xFFFFFF);
        });
    }

    private void updateStats() {
        // НЕ итерируем по всем сущностям каждый кадр (это вызывало фризы) —
        // берём кэшированные счётчики из оптимизаторов.
        if (OptiForgeMod.entityOptimizer != null && OptiForgeMod.entityOptimizer.isScanned()) {
            entityCount = OptiForgeMod.entityOptimizer.getLastLivingCount();
        }
        if (OptiForgeMod.entityOptimizer != null) culledEntities = OptiForgeMod.entityOptimizer.getCulledCount();
        if (OptiForgeMod.particleOptimizer != null) particleCount = OptiForgeMod.particleOptimizer.getTotalParticles();
        if (OptiForgeMod.blockEntityOptimizer != null) culledBlockEntities = OptiForgeMod.blockEntityOptimizer.getCulledCount();
        parseFps();
    }

    private void parseFps() {
        try {
            if (mc.field_1770 != null) {
                String s = mc.field_1770;
                int space = s.indexOf(' ');
                if (space > 0) {
                    fps = Integer.parseInt(s.substring(0, space));
                }
            }
        } catch (Exception ignored) {
        }
    }

    private void draw(class_4587 matrixStack, String text, int x, int y, int color) {
        mc.field_1772.method_1720(matrixStack, text, x, y, color);
    }
}
