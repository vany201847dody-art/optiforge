package com.vizor.optiforge;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import java.util.HashSet;
import java.util.Set;

public class BlockEntityOptimizer {

    private final Set<Long> culledPositions = new HashSet<>();
    private int tickCounter = 0;

    public void register() {
        ClientTickEvents.START_CLIENT_TICK.register(client -> {
            tickCounter++;
            // Реже сканируем блок-энтити (было каждый 10 тик). Сдвиг фазы так,
            // чтобы не совпадало со сканами сущностей/дропа (отдельные "заикания").
            if (tickCounter % 40 != 0) return;
            if (!ModConfig.blockEntityCulling) return;

            class_310 mc = class_310.method_1551();
            if (mc.field_1687 == null || mc.field_1724 == null) {
                culledPositions.clear();
                return;
            }

            culledPositions.clear();

            double camX = mc.field_1724.method_23317();
            double camY = mc.field_1724.method_23318();
            double camZ = mc.field_1724.method_23321();
            double maxDistSq = 128.0 * 128.0;
            // Дорогая проверка "полностью окружён блоками" только вблизи игрока
            double nearSq = 32.0 * 32.0;

            for (class_2586 be : mc.field_1687.field_9231) {
                if (be instanceof net.minecraft.class_2595) continue;
                if (be instanceof net.minecraft.class_2625) continue;
                if (be instanceof net.minecraft.class_2573) continue;

                class_2338 pos = be.method_11016();
                double dx = pos.method_10263() + 0.5 - camX;
                double dy = pos.method_10264() + 0.5 - camY;
                double dz = pos.method_10260() + 0.5 - camZ;
                double distSq = dx * dx + dy * dy + dz * dz;

                if (distSq > maxDistSq) {
                    culledPositions.add(pos.method_10063());
                    continue;
                }

                // Проверка закупоренности только для близких — для дальних дешёвая дистанция
                if (distSq <= nearSq && isFullySurrounded(mc, pos)) {
                    culledPositions.add(pos.method_10063());
                }
            }
        });
    }

    private boolean isFullySurrounded(class_310 mc, class_2338 pos) {
        return isSolid(mc, pos.method_10095())
                && isSolid(mc, pos.method_10072())
                && isSolid(mc, pos.method_10078())
                && isSolid(mc, pos.method_10067())
                && isSolid(mc, pos.method_10084())
                && isSolid(mc, pos.method_10074());
    }

    private boolean isSolid(class_310 mc, class_2338 pos) {
        return mc.field_1687.method_8320(pos).method_26216(mc.field_1687, pos);
    }

    public boolean isBlockEntityCulled(class_2586 be) {
        if (!ModConfig.blockEntityCulling) return false;
        return culledPositions.contains(be.method_11016().method_10063());
    }

    public int getCulledCount() {
        return culledPositions.size();
    }
}
