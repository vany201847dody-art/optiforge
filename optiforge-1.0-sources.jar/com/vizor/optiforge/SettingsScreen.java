package com.vizor.optiforge;

import net.minecraft.class_2585;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_4587;

public class SettingsScreen extends class_437 {

    public SettingsScreen() {
        super(new class_2585("Настройки OptiForge"));
    }

    private void rebuild() {
        class_310.method_1551().method_1507(new SettingsScreen());
    }

    @Override
    protected void method_25426() {
        int centerX = this.field_22789 / 2;
        int btnWidth = 280;
        int btnHeight = 20;
        int y = 28;

        // Кнопка автоопределения — применяет подходящие настройки под железо + моды
        this.method_25411(new class_4185(centerX - btnWidth / 2, y, btnWidth, 22,
                new class_2585("§a§l⚡ ОПРЕДЕЛИТЬ НАСТРОЙКИ ПОД МОЁ ЖЕЛЕЗО"),
                button -> {
                    OptiForgeMod.applyAutoDetectNow();
                    rebuild();
                }));
        y += 28;

        this.method_25411(new class_4185(centerX - btnWidth / 2, y, btnWidth, btnHeight,
                toggle("Оптимизация сущностей", ModConfig.entityCulling),
                button -> { ModConfig.entityCulling = !ModConfig.entityCulling; ModConfig.save(); rebuild(); }));
        y += 24;

        this.method_25411(new class_4185(centerX - btnWidth / 2, y, btnWidth, btnHeight,
                toggle("Пропускать тики дальних мобов", ModConfig.skipEntityTicks),
                button -> { ModConfig.skipEntityTicks = !ModConfig.skipEntityTicks; ModConfig.save(); rebuild(); }));
        y += 24;

        this.method_25411(new class_4185(centerX - btnWidth / 2, y, btnWidth, btnHeight,
                toggle("Ограничить частицы", ModConfig.optimizedParticles),
                button -> { ModConfig.optimizedParticles = !ModConfig.optimizedParticles; ModConfig.save(); GameSettingsApplier.apply(); rebuild(); }));
        y += 24;

        this.method_25411(new class_4185(centerX - btnWidth / 2, y, btnWidth, btnHeight,
                toggle("Оптимизация предметов (дроп)", ModConfig.optimizeItems),
                button -> { ModConfig.optimizeItems = !ModConfig.optimizeItems; ModConfig.save(); rebuild(); }));
        y += 24;

        this.method_25411(new class_4185(centerX - btnWidth / 2, y, btnWidth, btnHeight,
                toggle("Оптимизация блок-энтити", ModConfig.blockEntityCulling),
                button -> { ModConfig.blockEntityCulling = !ModConfig.blockEntityCulling; ModConfig.save(); rebuild(); }));
        y += 24;

        this.method_25411(new class_4185(centerX - btnWidth / 2, y, btnWidth, btnHeight,
                toggle("Автоопределение при входе", ModConfig.autoDetect),
                button -> { ModConfig.autoDetect = !ModConfig.autoDetect; ModConfig.save(); rebuild(); }));
        y += 24;

        this.method_25411(new class_4185(centerX - btnWidth / 2, y, btnWidth, btnHeight,
                toggle("Показать HUD", ModConfig.showFpsHud),
                button -> { ModConfig.showFpsHud = !ModConfig.showFpsHud; ModConfig.save(); rebuild(); }));
        y += 28;

        this.method_25411(new class_4185(centerX - btnWidth / 2, y, btnWidth, btnHeight,
                new class_2585("Готово"), button -> this.method_25419()));
    }

    private class_2585 toggle(String name, boolean enabled) {
        return new class_2585(name + ": " + (enabled ? "§aВКЛ" : "§cВЫКЛ"));
    }

    @Override
    public void method_25394(class_4587 matrices, int mouseX, int mouseY, float delta) {
        this.method_25420(matrices);
        net.minecraft.class_332.method_25300(matrices, this.field_22793,
                "§6§lOptiForge §7— §fоптимизация Minecraft", this.field_22789 / 2, 10, 0xFFFFFF);

        int h = this.field_22790 - 4;
        field_22793.method_1720(matrices, "§7Железо: " + HardwareDetector.getSummary(), 4, h - 42, 0xFFFFFF);
        field_22793.method_1720(matrices, "§7" + ModDetector.getOptimmodsSummary(), 4, h - 26, 0xFFFFFF);
        field_22793.method_1720(matrices, "§7" + ModDetector.getCustomModsSummary(), 4, h - 10, 0xFFFFFF);

        super.method_25394(matrices, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25422() {
        return true;
    }
}
